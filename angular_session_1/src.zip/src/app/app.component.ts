import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'input-display';
  input_text :any;
  logs : Array<any> = [];
  
  onInputChange(event)
  {
    this.input_text = event;
    this.logs.push({key_pressed_at : new Date() ,text : event});
  
  }
  constructor() { }

  ngOnInit(): void {
  }
 

}
