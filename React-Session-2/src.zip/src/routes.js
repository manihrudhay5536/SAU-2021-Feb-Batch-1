import React from 'react'
import Home from './components/home'
import { Add } from "./components/Add";
import { Detail } from "./components/Detail";
import { Search } from "./components/Search";
import {BrowserRouter as Router,Link,Switch,Route} from 'react-router-dom'
import { Container, Nav, Navbar } from 'react-bootstrap';
export default function Routes()
{

    return (
      <Router>
       <Route exact path="/">
            <Home />
          </Route>
        <Container>
        <Switch>
          <Route path="/list" >
            <Search/>
          </Route>
          <Route path="/add">
            <Add/>
          </Route>
          <Switch>
            <Route path="/detail/:id" children={<Detail />} />
          </Switch>
        </Switch>
        </Container>
    </Router>
    );
}