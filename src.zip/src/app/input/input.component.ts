import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.css']
})


export class InputComponent implements OnInit {
  input_text :any;
  logs : Array<any> = [];
  
  onInputChange(event:any)
  {
    this.input_text = (event.target as HTMLInputElement).value;
    this.logs.push({key_pressed_at : new Date() ,text : this.input_text});
  
  }

  constructor() { }

  ngOnInit(): void {
  }

}
