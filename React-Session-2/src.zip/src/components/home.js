import React from 'react'
import {Link} from 'react-router-dom'

function Home() {
    return (
        <div>
       <nav>
         <h1>My BookStore</h1>
        </nav>
       <ul>
            <li> <Link to="/list">List Books </Link></li>
           <li>  <Link to="/add">Add Books</Link></li>
        </ul>
         </div>
    );
  }
  
  export default Home;
